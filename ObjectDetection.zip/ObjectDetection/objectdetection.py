import cv2
from ultralytics import YOLO

# Load YOLOv8 model
model = YOLO("yolov8n.pt")  # Use 'yolov8s.pt' or 'yolov8m.pt' for better accuracy

# Start video capture
cap = cv2.VideoCapture(0)  # 0 for default webcam, change to video file path if needed

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Run YOLO model on the frame
    results = model(frame)

    # Get processed frame with bounding boxes
    result_frame = results[0].plot()

    # Display the frame
    cv2.imshow("YOLOv8 Live Object Detection", result_frame)

    # Press 'q' to exit
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
